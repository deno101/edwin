package com.example.campusvotingsystemcvs;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;

public class UploadData {

    public UploadData() {
    }

    /**
     * @Param sectionName   The desired title for the section
     * @Param candidateList The desired candidateList to be
     *                      uploaded. The format for candidateList
     *                      must match the Candidate class as defined
     *                      in the documentation.
     */

    public static class Uploader{
        private String sectionName;
        private ArrayList<Candidate> candidateList;
        private DatabaseReference mCandDatabaseRef;
        private boolean result;
        public Uploader() {
        }

        // Returns true if data is uploaded successfully, otherwise returns false
        public boolean upload(String sectionName, ArrayList<Candidate> candidateList){

            mCandDatabaseRef = CVSDatabase.getDatabase().getReference("candidates");
            for (Candidate candidate : candidateList){
                mCandDatabaseRef.child(sectionName).push().setValue(candidate).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        result = task.isSuccessful();
                    }
                });
            }
            return result;
        }

    }
}
