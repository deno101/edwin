package com.example.campusvotingsystemcvs;



public class VotedUser {
    private  String email;

    public VotedUser() {
    }

    public VotedUser(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}


