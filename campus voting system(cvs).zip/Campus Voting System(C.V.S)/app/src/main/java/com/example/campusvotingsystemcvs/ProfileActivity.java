package com.example.campusvotingsystemcvs;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import static android.widget.Toast.LENGTH_SHORT;

public class ProfileActivity extends AppCompatActivity {

    Button pollVoteBtn,viewResultBtn,signOutBtn;
    private TextView txtViewStatus;
    private FirebaseAuth mFirebaseAuth;
    private DatabaseReference mTimeDatabaseRef,mUserDatabaseRef;
    private FirebaseUser mFirebaseUser;
    private FirebaseAuth.AuthStateListener authStateListener;
    private static boolean isVoted;
    private static boolean isPollStarted;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        isVoted =false;
        isPollStarted =false;
        mTimeDatabaseRef = CVSDatabase.getDatabase().getReference("pollTime");
        mUserDatabaseRef = CVSDatabase.getDatabase().getReference("whitelist");
        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseUser = mFirebaseAuth.getCurrentUser();
        signOutBtn = findViewById(R.id.email_sign_out_button);
        pollVoteBtn = findViewById(R.id.poll_vote_button);
        viewResultBtn = findViewById(R.id.view_result_button);
        txtViewStatus = findViewById(R.id.textView_user_status);

        checkStatus();
        // Sign out the user
        signOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ProfileActivity.this, "Good bye: "+mFirebaseUser.getEmail(), LENGTH_SHORT).show();
                mFirebaseAuth.signOut();
            }
        });
//        // Polling vote
        pollVoteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkStatus();
                if (!isVoted && isPollStarted) {
                    Toast.makeText(ProfileActivity.this, "Have a nice poll "+mFirebaseUser.getEmail(), LENGTH_SHORT).show();
                    startActivity(new Intent(ProfileActivity.this, PollActivity.class));
                }else if ((!isVoted && !isPollStarted) || (isVoted && !isPollStarted)){
                    Toast.makeText(ProfileActivity.this, "Poll has been finished", LENGTH_SHORT).show();
                }else if (isVoted && isPollStarted){
                    Toast.makeText(ProfileActivity.this, "You have already casted in poll", LENGTH_SHORT).show();
                }
            }
        });
        // Viewing the polling results
        viewResultBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkStatus();

//                Handler handler = new Handler();
//                handler.postDelayed(new Runnable() {
//                    public void run() {
//                        // Actions to do after 5 seconds
//                    }
//                }, 5000);
                //startActivity(new Intent(ProfileActivity.this, ProfileActivity.class));
                startActivity(new Intent(ProfileActivity.this, ResultsActivity.class));
                startActivity(new Intent(ProfileActivity.this, ProfileActivity.class));

                if (isPollStarted) {
                    Toast.makeText(ProfileActivity.this, "Poll is in progress please wait", LENGTH_SHORT).show();
                }else if (!isPollStarted){
                    Toast.makeText(ProfileActivity.this, "Poll has been finished", LENGTH_SHORT).show();
                    startActivity(new Intent(ProfileActivity.this, ResultsActivity.class));
                }
                //handler.removeCallbacksAndMessages(null);
            }
        });

        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if (firebaseAuth.getCurrentUser() != null){
                    // user has been logged in, update the UI, , translate to the profile activity
                    //updateUI(mFirebaseUser);
                    txtViewStatus.setText(firebaseAuth.getCurrentUser().getEmail());

                }
                else {
                    finish();
                    startActivity(new Intent(ProfileActivity.this, MainActivity.class));
                }

            }
        };
    }

    private void checkStatus() {
        mTimeDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                isPollStarted = dataSnapshot.child("time").getValue(String.class).equals("start");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        if (mUserDatabaseRef !=null) {
            mUserDatabaseRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot email : dataSnapshot.getChildren()) {
                        if(email.child("email").getValue(String.class).equals(mFirebaseUser.getEmail())){
                            isVoted =true;
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }


    @Override
    protected void onStart() {
        super.onStart();
        mFirebaseAuth.addAuthStateListener(authStateListener);
        //checkStatus();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        checkStatus();
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        if (mFirebaseUser != null){
            menu.findItem(R.id.user_status).setTitle(mFirebaseUser.getEmail());
            menu.add(R.string.action_sign_out).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    mFirebaseAuth.signOut();
                    return true;
                }
            });
            mTimeDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.child("time").getValue(String.class) != null) {
                        menu.findItem(R.id.poll_timeView).setTitle("Poll Time: " + dataSnapshot.child("time").getValue(String.class));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_help:
                // User chose the "Help" item, show help.
                startActivity(new Intent(ProfileActivity.this, HelpActivity.class));
                return true;

            default:
                // If got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //checkStatus();
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
//        if (mFirebaseUser != null){
//            menu.findItem(R.id.user_status).setTitle(mFirebaseUser.getEmail());
//        }
        return super.onPrepareOptionsMenu(menu);
    }
    // Show views
    private void enableViews(View... views) {
        for (View v : views) {
            v.setEnabled(true);
        }
    }

    // Hide views
    private void disableViews(View... views) {
        for (View v : views) {
            v.setEnabled(false);
        }
    }
}


