package com.example.campusvotingsystemcvs;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerTabStrip;
import androidx.viewpager.widget.ViewPager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ResultsActivity extends AppCompatActivity {

    private String pollStatus;
    private DatabaseReference mTimeDatabaseRef;
    private DatabaseReference mCandDatabaseRef;
    private FirebaseAuth mFirebaseAuth;
    private FirebaseUser mFirebaseUser;
    private FirebaseAuth.AuthStateListener authStateListener;
    Toolbar toolbar;
    PagerTabStrip tabStrip;
    private ViewPager mViewPager;
    private ArrayList<String> candidateKeyList;
    private ArrayList<Data> dataList;
    private ArrayList<KeyStore> keyStoreList;
    private ArrayList<Candidate> candidateList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        mTimeDatabaseRef = CVSDatabase.getDatabase().getReference("pollTime");
        mCandDatabaseRef = CVSDatabase.getDatabase().getReference("candidates");
        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseUser = mFirebaseAuth.getCurrentUser();
        // Extracting username from email
//        String regExp = "^(.+\\S*)@";
//        Pattern uNamePattern =  Pattern.compile(regExp);
//        Matcher matcher = uNamePattern.matcher(mFirebaseUser.getEmail());
//        userName = matcher.toString();
        toolbar = findViewById(R.id.toolbar_results);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tabStrip = findViewById(R.id.pager_header_results);
        tabStrip.setTextColor(getResources().getColor(R.color.BLACK));
        mViewPager = findViewById(R.id.container_fragment_results);
        keyStoreList = new ArrayList <>();
        dataList = new ArrayList <>();

        authStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if (firebaseAuth.getCurrentUser() != null) {
                    // user has been logged in enable views
                    enableViews(mViewPager, toolbar, tabStrip);
                } else {
                    //txtViewStatus.setText(R.string.user_status);
                    disableViews(mViewPager, toolbar, tabStrip);
                    startActivity(new Intent(ResultsActivity.this, ProfileActivity.class));
                    finish();
                }

            }
        };

        /*
          Attempt to load data from the backend.
          If the loading fails, the
          errors are presented and no data will be load.
         */
//        mCandDatabaseRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                String titleKey;
//                for (DataSnapshot section : dataSnapshot.getChildren()) {
//                    titleKey = section.getKey();
//                    candidateKeyList = new ArrayList <>();
//                    candidateList = new ArrayList <>();
//                    for (DataSnapshot candidate : section.getChildren()) {
//                        candidateKeyList.add(candidate.getKey());
//                        candidateList.add(candidate.getValue(Candidate.class));
//                    } //End of inner loop
//                    // Storing data Keys
//                    keyStoreList.add(new KeyStore(titleKey, candidateKeyList));
//                    // Storing data
//                    setDataList(new Data(titleKey, candidateList));
//                }// End of outer loop
//                mViewPager.getAdapter().notifyDataSetChanged();
//                //Toast.makeText(getBaseContext(), "Data successfully loaded", LENGTH_SHORT).show();
//            }
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//            }
//        });

        mCandDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String titleKey;
                for (DataSnapshot section : dataSnapshot.getChildren()) {
                    titleKey = section.getKey();
                    candidateKeyList = new ArrayList <>();
                    candidateList = new ArrayList <>();
                    for (DataSnapshot candidate : section.getChildren()) {
                        candidateKeyList.add(candidate.getKey());
                        candidateList.add(candidate.getValue(Candidate.class));
                    } //End of inner loop
                    // Storing data Keys
                    keyStoreList.add(new KeyStore(titleKey, candidateKeyList));
                    // Storing data
                    setDataList(new Data(titleKey, candidateList));
                }// End of outer loop
                mViewPager.getAdapter().notifyDataSetChanged();
                //Toast.makeText(getBaseContext(), "Data successfully loaded", LENGTH_SHORT).show();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        /*
      The {@link ViewPager} that will host the section contents.
      */
        mViewPager.setAdapter(new SectionsPagerAdapter(getSupportFragmentManager()));
        TabLayout tabLayout = findViewById(R.id.sliding_tab_results);
        tabLayout.setupWithViewPager(mViewPager, true);

    }// End of onCreate() method

    //Setting the data
    private void setDataList(Data data) {
        this.dataList.add(data);
    }

    public Data getSectionData(int sectionNo){
        return this.dataList.get(sectionNo);
    }
    // Show views
    private void enableViews(View... views) {
        for (View v : views) {
            v.setEnabled(true);
        }
    }

    // Hide views
    private void disableViews(View... views) {
        for (View v : views) {
            v.setEnabled(false);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        mFirebaseAuth.addAuthStateListener(authStateListener);
    }
    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        //menu.findItem(R.id.poll_timeView).setTitle("Poll Time: "+"END");
        if (mFirebaseUser != null){
            menu.findItem(R.id.user_status).setTitle(mFirebaseUser.getEmail());
            menu.add(R.string.action_sign_out).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    mFirebaseAuth.signOut();
                    return true;
                }
            });
            mTimeDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    menu.findItem(R.id.poll_timeView).setTitle("Poll Time: "+dataSnapshot.child("time").getValue(String.class));
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case R.id.action_help:
                // User chose the "Help" item, show help.
                startActivity(new Intent(ResultsActivity.this, HelpActivity.class));
                return true;


            default:
                // If got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {
        private int sectionNo;
        private Data sectionData;
        private RecyclerView recyclerView;
        /**
         * The fragment argument representing the section number for this
         * fragment.
         */
        private static final String ARG_SECTION_NUMBER = "SECTION_NUMBER";

        public PlaceholderFragment() {
        }

        /**
         * Returns a new instance of this fragment for the given section
         * number.
         */
        public static PlaceholderFragment newInstance(int sectionNumber) {
            PlaceholderFragment fragment = new PlaceholderFragment();
            Bundle args = new Bundle();
            args.putInt(ARG_SECTION_NUMBER, sectionNumber);
            fragment.setArguments(args);
            return fragment;
        }

        @Override
        public void onCreate(@Nullable Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            sectionData = new Data();
            sectionNo = this.getArguments().getInt(ARG_SECTION_NUMBER);
            // Grab data from activity class
            sectionData = ((ResultsActivity)getActivity()).getSectionData(sectionNo);
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_results, container, false);
            recyclerView = rootView.findViewById(R.id.recyclerView_results);
            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
            container.getChildAt(1);
            recyclerView.setAdapter(new AdapterResults(getActivity(), sectionData));
            recyclerView.getAdapter().notifyDataSetChanged();
            return rootView;
        }
    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
     * one of the sections/tabs/pages.
     */
    public class SectionsPagerAdapter extends FragmentPagerAdapter {

        SectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            // getItem is called to instantiate the fragment for the given page.
            // Return a PlaceholderFragment (defined as a static inner class below).
            return PlaceholderFragment.newInstance(position);
        }
        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {}

        @Override
        public int getCount() {
            //Add page.
            return keyStoreList.size();
        }
        // Returns the page title for the top indicator
        @Override
        public CharSequence getPageTitle(int position) {
            return keyStoreList.get(position).getTitleKey();
        }
    }
}
