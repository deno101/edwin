package com.example.campusvotingsystemcvs;

import java.util.ArrayList;

public class Data {


    private String sectionName;
    private ArrayList<Candidate> candidateList;

    public Data() {
    }

    public Data(String sectionName, ArrayList <Candidate> candidateList) {
        this.sectionName = sectionName;
        this.candidateList = candidateList;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public ArrayList <Candidate> getCandidateList() {
        return candidateList;
    }

    public void setCandidateList(ArrayList <Candidate> candidateList) {
        this.candidateList = candidateList;
    }
}
