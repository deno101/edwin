package com.example.campusvotingsystemcvs;

import android.view.View;

/**
 * Created by AliaX on 5/6/2018.
 */

public interface CustomItemClickListener {
    public void onItemClick(View v, int position);
    }
