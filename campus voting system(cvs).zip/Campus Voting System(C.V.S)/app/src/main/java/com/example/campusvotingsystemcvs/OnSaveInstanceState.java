package com.example.campusvotingsystemcvs;

class OnSaveInstanceState {
}
