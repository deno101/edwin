package com.example.campusvotingsystemcvs;

public class VoterInformation {


    private String email;
    private String phone;
    private String pseudoID;
    private boolean voteStatus;

    public VoterInformation(){

    }

    public VoterInformation(String email, String password, String phone, String pseudoID, boolean voteStatus) {
        this.email = email;
        this.phone = phone;
        this.pseudoID = pseudoID;
        this.voteStatus = voteStatus;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setPseudoID(String pseudoID) {
        this.pseudoID = pseudoID;
    }

    public void setVoteStatus(boolean voteStatus) {
        this.voteStatus = voteStatus;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getPseudoID() {
        return pseudoID;
    }

    public boolean isVoteStatus() {
        return voteStatus;
    }
}

