package com.example.campusvotingsystemcvs;

public class Caster {

    private String sectionName,candidateKey;
    private int sectionNo,candidatePos;
    private boolean isVoted;

    Caster() {
    }

    public Caster(String sectionName, int candidatePos, boolean isVoted, String candidateKey) {
        this.sectionName = sectionName;
        this.candidatePos = candidatePos;
        this.isVoted = isVoted;
        this.candidateKey = candidateKey;
    }

    String getSectionName() {
        return sectionName;
    }

    void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }
    public int getSectionNo() {
        return sectionNo;
    }

    public void setSectionNo(int sectionNo) {
        this.sectionNo = sectionNo;
    }
    int getCandidatePos() {
        return candidatePos;
    }

    void setCandidatePos(int candidatePos) {
        this.candidatePos = candidatePos;
    }

    boolean isVoted() {
        return isVoted;
    }

    void setVoted(boolean voted) {
        isVoted = voted;
    }

    public String getCandidateKey() {
        return candidateKey;
    }

    public void setCandidateKey(String candidateKey) {
        this.candidateKey = candidateKey;
    }
}

