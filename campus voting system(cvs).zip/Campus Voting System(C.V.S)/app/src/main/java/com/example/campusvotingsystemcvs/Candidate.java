package com.example.campusvotingsystemcvs;

import com.google.firebase.database.IgnoreExtraProperties;

/**
 * Created by AliaX on 5/11/2018.
 */
@IgnoreExtraProperties
public class Candidate {
    private String candName,email,phone, photoUrl, symbolUrl;
    private int voteCount;

    // Required empty constructor
    public Candidate(){}

    Candidate(String candName, String email, String phone, int voteCount, String photoUrl, String symbolUrl) {
        this.candName = candName;
        this.email = email;
        this.phone = phone;
        this.voteCount = voteCount;
        this.photoUrl = photoUrl;
        this.symbolUrl = symbolUrl;
    }

    public void setCandName(String candName) {
        this.candName = candName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setVoteCount(int voteCount) {
        this.voteCount = voteCount;
    }

    public String getCandName() {
        return candName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public int getVoteCount() {
        return voteCount;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public String getSymbolUrl() {
        return symbolUrl;
    }

    public void setSymbolUrl(String symbolUrl) {
        this.symbolUrl = symbolUrl;
    }
}
