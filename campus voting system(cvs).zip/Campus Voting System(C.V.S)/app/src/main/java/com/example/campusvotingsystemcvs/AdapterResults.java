package com.example.campusvotingsystemcvs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

public class AdapterResults extends RecyclerView.Adapter{

    private Context context;
    private Data sectionData;

    AdapterResults(Context context, Data sectionData){
        this.context = context;
        this.sectionData = sectionData;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    // Creates and returns a view for a single element of the recycler view
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.results_single_item, parent, false));
        //final View mView = LayoutInflater.from(context).inflate(R.layout.poll_single_row, parent, false);
        //return new ViewHolder(mView);
    }

    // Sets the contents of the view which is returned by onCreateViewHolder
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Candidate candidate = sectionData.getCandidateList().get(position);
        Picasso.get().load(candidate.getPhotoUrl()).into(((ViewHolder)holder).imgCand);
        ((ViewHolder)holder).candName.setText(candidate.getCandName());
        ((ViewHolder)holder).voteCount.setText(String.format("Votes: %d",candidate.getVoteCount()));

    }
    @Override
    public int getItemCount() {
        return sectionData.getCandidateList().size();
    }

    // Provides a reference to the views for each data item in PollActivity
    class ViewHolder extends RecyclerView.ViewHolder{
        TextView candName, voteCount;
        ImageView imgCand;
        ViewHolder(View itemView) {
            super(itemView);
            candName = (itemView).findViewById(R.id.cand_name_results);
            imgCand = (itemView).findViewById(R.id.pic_cand_results);
            voteCount = (itemView).findViewById(R.id.voteCount_results);
        }
    }
}
