package com.example.campusvotingsystemcvs;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

public class AdapterPoll extends RecyclerView.Adapter{

    private Context context;
    private CustomItemClickListener listener;
    private Data sectionData;
    private int lastSelectedPosition = -1;

    AdapterPoll(Context context, Data sectionData, CustomItemClickListener listener){
        this.context = context;
        this.listener = listener;
        this.sectionData = sectionData;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    // Creates and returns a view for a single element of the recycler view
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.poll_single_row, parent, false));
        //final View mView = LayoutInflater.from(context).inflate(R.layout.poll_single_row, parent, false);
        //return new ViewHolder(mView);
    }

    // Sets the contents of the view which is returned by onCreateViewHolder
    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Candidate candidate = sectionData.getCandidateList().get(position);
        Picasso.get().load(candidate.getPhotoUrl()).into(((ViewHolder)holder).imgCand);
        Picasso.get().load(candidate.getSymbolUrl()).into(((ViewHolder)holder).imgSymbol);
        ((ViewHolder)holder).candName.setText(candidate.getCandName());
        ((ViewHolder)holder).selectionState.setChecked(lastSelectedPosition == position);
    }
    @Override
    public int getItemCount() {
        return sectionData.getCandidateList().size();
    }

    // Provides a reference to the views for each data item in PollActivity
    class ViewHolder extends RecyclerView.ViewHolder{
        TextView candName;
        RadioButton selectionState;
        ImageView imgCand, imgSymbol;
        ViewHolder(View itemView) {
            super(itemView);
            candName = (itemView).findViewById(R.id.cand_name_poll);
            imgCand = (itemView).findViewById(R.id.pic_cand_poll);
            imgSymbol = (itemView).findViewById(R.id.cand_symbol_poll);
            selectionState = (itemView).findViewById(R.id.vote_selector);
            selectionState.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    lastSelectedPosition = getAdapterPosition();
                    listener.onItemClick(v, lastSelectedPosition);
                    notifyDataSetChanged();
                }
            });
        }
    }
}

